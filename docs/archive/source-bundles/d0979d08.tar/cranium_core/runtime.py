from typing import Any, Dict, Optional

from .field import ResonanceField
from .physics import PhysicsEngine
from .directives import DirectiveResolver
from .spiral import CognitiveSpiral
from .artifacts import CognitiveArtifact


class CraniumRuntime:
    def __init__(self, field: Optional[ResonanceField] = None):
        self.field = field or ResonanceField()
        self.physics = PhysicsEngine()
        self.directives = DirectiveResolver(self.physics)
        self.spiral = CognitiveSpiral(self.field, self.physics, self.directives)

    def handle_event(self, event: Dict[str, Any]) -> CognitiveArtifact:
        return self.spiral.step(event)
