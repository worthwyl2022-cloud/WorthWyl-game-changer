from dataclasses import dataclass
from typing import List


@dataclass
class CognitiveAtom:
    id: str
    charge: float
    mass: float
    velocity: float
    tags: List[str]
    embedding: List[float]
    lineage: List[str]

    @property
    def energy(self) -> float:
        """Computed energy of the atom based on charge, mass, and velocity."""
        return abs(self.charge) * self.mass * (0.4 + 0.6 * self.velocity)
