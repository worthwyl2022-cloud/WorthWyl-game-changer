from typing import Any, Dict

from .field import ResonanceField
from .physics import PhysicsEngine
from .directives import DirectiveResolver, Directive
from .artifacts import CognitiveArtifact


class CognitiveSpiral:
    def __init__(
        self,
        field: ResonanceField,
        physics: PhysicsEngine,
        directives: DirectiveResolver,
    ):
        self.field = field
        self.physics = physics
        self.directives = directives

    def step(self, input_event: Dict[str, Any]) -> CognitiveArtifact:
        """Run one cognitive/narrative cycle for an input event."""
        self._perceive(input_event)

        metrics = self.physics.evaluate(self.field)
        directive = self.directives.resolve(self.field)

        self.apply_directive(directive)
        artifact = self.generate_artifact(metrics, directive)

        self.inject_atom_from_artifact(artifact)
        self.physics.evaluate(self.field)

        return artifact

    def _perceive(self, event: Dict[str, Any]) -> None:
        event_id = event.get("id", "event")
        self.field.record_event(event_id)

    def apply_directive(self, directive: Directive) -> None:
        if directive == Directive.ESCALATE_TENSION:
            self.field.adjust_tension(0.1)
        elif directive == Directive.REPAIR_CONTINUITY:
            self.field.update_theme_weight("continuity", 0.1)
        elif directive == Directive.DEEPEN_EMOTION:
            self.field.adjust_tension(0.05)
        elif directive == Directive.REANCHOR_THEME:
            self.field.update_theme_weight("theme_anchor", 0.1)

    def generate_artifact(
        self,
        metrics: Dict[str, float],
        directive: Directive,
    ) -> "CognitiveArtifact":
        body = f"Directive: {directive.name}\nMetrics: {metrics}"
        return CognitiveArtifact.from_state(self.field, body, directive, metrics)

    def inject_atom_from_artifact(self, artifact: CognitiveArtifact) -> None:
        atom = artifact.to_atom()
        self.field.add_atom(atom)
