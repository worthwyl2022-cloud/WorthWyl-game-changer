from dataclasses import dataclass, field
from typing import Dict, List

from .atoms import CognitiveAtom


@dataclass
class ResonanceField:
    atoms: List[CognitiveAtom] = field(default_factory=list)
    theme_weights: Dict[str, float] = field(default_factory=dict)
    tension: float = 0.5
    baseline: float = 0.5
    drift_velocity: float = 0.0
    lineage: List[str] = field(default_factory=list)

    def add_atom(self, atom: CognitiveAtom) -> None:
        self.atoms.append(atom)

    def adjust_tension(self, delta: float) -> None:
        self.tension = max(0.0, min(1.0, self.tension + delta))

    def update_theme_weight(self, key: str, delta: float) -> None:
        self.theme_weights[key] = self.theme_weights.get(key, 0.0) + delta

    def record_event(self, event_id: str) -> None:
        self.lineage.append(event_id)
