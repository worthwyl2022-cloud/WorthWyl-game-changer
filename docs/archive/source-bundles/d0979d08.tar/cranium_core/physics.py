from typing import Dict

from .field import ResonanceField


class PhysicsEngine:
    def evaluate(self, field: ResonanceField) -> Dict[str, float]:
        """Return a dictionary of narrative/cognitive metrics for the field."""
        return {
            "continuity": self._continuity(field),
            "emotional_flatness": self.emotional_flatness(field),
            "theme_drift": self.theme_drift(field),
            "motive_starvation": self.motive_starvation(field),
            "tension_collapse": self.tension_collapse(field),
            "coherence_break": self.coherence_break(field),
        }

    def _continuity(self, field: ResonanceField) -> float:
        return min(1.0, len(field.lineage) / 10.0)

    def emotional_flatness(self, field: ResonanceField) -> float:
        if not field.atoms:
            return 1.0
        charges = [abs(a.charge) for a in field.atoms]
        avg = sum(charges) / len(charges)
        return max(0.0, 1.0 - avg)

    def theme_drift(self, field: ResonanceField) -> float:
        return min(1.0, field.drift_velocity)

    def motive_starvation(self, field: ResonanceField) -> float:
        if not field.atoms:
            return 1.0
        velocities = [a.velocity for a in field.atoms]
        avg = sum(velocities) / len(velocities)
        return max(0.0, 1.0 - avg)

    def tension_collapse(self, field: ResonanceField) -> float:
        return max(0.0, 1.0 - field.tension)

    def coherence_break(self, field: ResonanceField) -> float:
        positive = sum(1 for a in field.atoms if a.charge > 0)
        negative = sum(1 for a in field.atoms if a.charge < 0)
        total = positive + negative
        if total == 0:
            return 0.0
        conflict_ratio = min(positive, negative) / total
        return conflict_ratio
