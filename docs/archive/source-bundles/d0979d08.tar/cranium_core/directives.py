from enum import Enum, auto

from .field import ResonanceField
from .physics import PhysicsEngine


class Directive(Enum):
    REPAIR_CONTINUITY = auto()
    DEEPEN_EMOTION = auto()
    ESCALATE_TENSION = auto()
    REANCHOR_THEME = auto()
    REFLECT = auto()


class DirectiveResolver:
    def __init__(self, physics: PhysicsEngine):
        self.physics = physics

    def resolve(self, field: ResonanceField) -> Directive:
        metrics = self.physics.evaluate(field)

        if metrics["continuity"] < 0.3:
            return Directive.REPAIR_CONTINUITY

        if metrics["emotional_flatness"] > 0.7:
            return Directive.DEEPEN_EMOTION

        if metrics["tension_collapse"] > 0.5:
            return Directive.ESCALATE_TENSION

        if metrics["theme_drift"] > 0.6:
            return Directive.REANCHOR_THEME

        return Directive.REFLECT
