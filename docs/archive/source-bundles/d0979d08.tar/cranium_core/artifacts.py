from dataclasses import dataclass
from typing import Dict, Any, List

from .field import ResonanceField
from .atoms import CognitiveAtom
from .directives import Directive


@dataclass
class CognitiveArtifact:
    body: str
    frontmatter: Dict[str, Any]
    tension: float
    directive: Directive
    lineage: List[str]
    tags: Dict[str, float]
    dissonance: Dict[str, float]

    @classmethod
    def from_state(
        cls,
        field: ResonanceField,
        body: str,
        directive: Directive,
        metrics: Dict[str, float],
    ) -> "CognitiveArtifact":
        tags: Dict[str, float] = {}
        for atom in field.atoms:
            for tag in atom.tags:
                tags[tag] = tags.get(tag, 0.0) + 1.0

        return cls(
            body=body,
            frontmatter={"theme_weights": field.theme_weights},
            tension=field.tension,
            directive=directive,
            lineage=list(field.lineage),
            tags=tags,
            dissonance=metrics,
        )

    def to_atom(self) -> CognitiveAtom:
        return CognitiveAtom(
            id="artifact_atom",
            charge=self.tension,
            mass=1.0,
            velocity=0.5,
            tags=list(self.tags.keys()),
            embedding=[],
            lineage=list(self.lineage),
        )
