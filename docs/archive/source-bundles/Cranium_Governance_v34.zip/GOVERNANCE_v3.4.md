# Cranium Substrate Governance v3.4 (Android)

## Added on main

| Module | Role |
|--------|------|
| `CanonLane.kt` | Immutable facts + factual-probe detection + CANON MODE steering |
| `ContradictionEngine.kt` | Dual-lane: affective (field) + logical NLI-proxy (opposition + cosine) |
| `OutputEvaluator.kt` | Identity/theme/constraint/novelty scores; pass gate for write-back |
| `DeliberationEngine.kt` | Metric-driven budget, directive procedures, multi-round revise |
| `SubstrateCore.kt` | Wired full loop + `seedCanon` / `approve` / `reject` / quarantine inbox |
| `ResonanceField.kt` | Real pairwise conflict + identity_pressure (not stubs) |

## Loop

```
intention
  → immune hard-block
  → human atom + field step
  → identity-biased retrieval
  → canon lane (if probe)
  → deliberation budget + generate*
  → immune + dual-lane contradiction
  → OutputEvaluator
  → quarantine only if passed
  → human approve() → episodic
```

## Honest limits

- NLI lane is a **deterministic proxy** (lexical opposition + embedding anti-alignment). Swap in CrossEncoder / on-device NLI when available.
- Canon probe detection is heuristic starters, not a classifier.
- Deliberation rounds capped at 4 for cost control.

## API surface

```kotlin
core.seedCanon(listOf("The signal has never been answered.", "..."))
core.injectIntention("How long has the ship been drifting?")
core.quarantineInbox()
core.approve(atomId)
core.reject(atomId)
```
