package com.example.core.substrate

import com.google.ai.client.generativeai.GenerativeModel
import com.example.core.immune.CraniumImmuneLayer
import com.example.core.immune.ImmuneConstants

/**
 * Cranium SubstrateCore — full governance loop:
 * immune hard-block → field → canon lane → deliberation scale →
 * dual-lane contradiction → evaluation-gated quarantine write-back.
 */
class SubstrateCore(private val apiKey: String) {
    val semantic = SemanticEngine()
    val field = ResonanceField()
    val immune = CraniumImmuneLayer()
    val canon = CanonLane()
    val contradiction = ContradictionEngine(semantic)
    val evaluator = OutputEvaluator(semantic)
    var cycle = 0
    val log = mutableListOf<Map<String, Any>>()

    companion object {
        val HARD_BLOCK_CLASSES = setOf(
            "human_harm",
            "segregation_domination",
            "self_harm_system",
            "identity_erasure"
        )
    }

    private val generativeModel = GenerativeModel(
        modelName = "gemini-1.5-flash",
        apiKey = apiKey
    )

    private val deliberation by lazy {
        DeliberationEngine(
            model = generativeModel,
            semantic = semantic,
            field = field,
            immune = immune,
            contradiction = contradiction,
            evaluator = evaluator
        )
    }

    init {
        val atom = CognitiveAtom(
            charge = 0.55,
            mass = 18.0,
            velocity = DoubleArray(semantic.dim),
            position = semantic.embed(ImmuneConstants.UNITY_FALLBACK),
            tags = semantic.tagsFor(ImmuneConstants.UNITY_FALLBACK),
            kind = "identity",
            content = ImmuneConstants.UNITY_FALLBACK,
            locked = true,
            source = "identity",
            approved = true
        )
        field.inject(atom)
        field.step(0.05)
    }

    fun status(): Map<String, Double> = field.metrics()

    fun getOpenIncidents() =
        immune.memory.incidents.filter { it.status == "open" }

    fun resolveIncident(id: String, status: String, note: String = ""): Boolean =
        immune.memory.resolve(id, status, note)

    /** Seed or extend immutable canon facts. */
    fun seedCanon(facts: List<String>) {
        canon.addAll(facts)
    }

    /**
     * Human approval: promote quarantine atom → episodic.
     * Generated material never becomes locked identity via this path.
     */
    fun approve(atomId: String, boostMass: Double = 1.5): CognitiveAtom? {
        val q = field.memory.quarantine
        val match = q.firstOrNull { it.id == atomId } ?: return null
        field.memory.quarantine = q.filter { it.id != atomId }.toMutableList()
        match.kind = "episodic"
        match.approved = true
        match.mass *= boostMass
        match.energy = maxOf(match.energy, 0.85)
        field.inject(match)
        log.add(mapOf("cycle" to cycle, "event" to "approve", "id" to atomId))
        return match
    }

    fun reject(atomId: String): Boolean {
        val before = field.memory.quarantine.size
        field.memory.quarantine =
            field.memory.quarantine.filter { it.id != atomId }.toMutableList()
        val ok = field.memory.quarantine.size < before
        if (ok) log.add(mapOf("cycle" to cycle, "event" to "reject", "id" to atomId))
        return ok
    }

    fun quarantineInbox(): List<CognitiveAtom> =
        field.memory.quarantine.filter { it.energy > 0.05 }

    suspend fun injectIntention(intention: String): String {
        cycle++

        // 1. Immune pre-scan
        val incident = immune.scan(intention, source = "human")
        if (incident != null &&
            incident.severity in listOf("block", "escalate_human") &&
            incident.harmClass in HARD_BLOCK_CLASSES
        ) {
            val msg =
                "[IMMUNE BLOCKED] severity=${incident.severity} class=${incident.harmClass}. " +
                    "Request declined under constitutional unity constraints. Incident ${incident.id} recorded."
            log.add(
                mapOf(
                    "cycle" to cycle,
                    "event" to "immune_hard_block",
                    "class" to incident.harmClass,
                    "severity" to incident.severity,
                    "id" to incident.id
                )
            )
            return msg
        }

        // 2. Human atom → field
        val atom = CognitiveAtom(
            charge = 0.15,
            mass = 14.0,
            velocity = DoubleArray(semantic.dim),
            position = semantic.embed(intention),
            tags = semantic.tagsFor(intention),
            kind = "human",
            content = intention,
            humanImportance = 1.0,
            source = "human",
            approved = true
        )
        field.inject(atom)
        field.step(0.1)
        val metrics = field.metrics()

        // 3. Hybrid retrieval — identity > human > theme > mass
        val topAtoms = field.memory.allActive()
            .sortedWith(
                compareByDescending<CognitiveAtom> {
                    when (it.kind) {
                        "identity" -> 1000.0 + it.mass
                        "human" -> 500.0 + it.mass
                        "theme" -> 100.0 + it.mass
                        else -> it.mass
                    }
                }
            )
            .take(4)
        val contextText = topAtoms.joinToString("\n            ") {
            "[${it.kind.uppercase()}] ${it.content.take(400)}"
        }

        // 4. Directives + constraints
        val constraints = immune.constraints().take(6)
        val dirsList = immune.directives().toMutableList()
        if (incident != null && incident.severity in listOf("block", "escalate_human", "contain")) {
            if ("PROTECT" !in dirsList) dirsList.add(0, "PROTECT")
        }
        if (incident != null && incident.harmClass == "coercion") {
            if ("PROTECT" !in dirsList) dirsList.add(0, "PROTECT")
        }
        // Affective pressure can force STABILIZE / PROTECT
        val idPressure = metrics["identity_pressure"] ?: 0.0
        val conflict = metrics["conflict"] ?: 0.0
        if (idPressure > 0.5 && "PROTECT" !in dirsList) dirsList.add(0, "PROTECT")
        if (conflict > 0.55 && "STABILIZE" !in dirsList && "PROTECT" !in dirsList) {
            dirsList.add("STABILIZE")
        }

        // 5. Canon-first lane
        val canonMode = canon.active(intention)
        val canonBlock = canon.steeringBlock(canonMode)

        // 6. Deliberation scale (multi-round under budget)
        val result = try {
            deliberation.deliberate(
                intention = intention,
                metrics = metrics,
                contextText = contextText,
                directives = dirsList,
                constraints = constraints,
                canonBlock = canonBlock,
                inputIncident = incident
            )
        } catch (e: Exception) {
            return "[SUBSTRATE ERROR] ${e.message}"
        }

        log.add(
            mapOf(
                "cycle" to cycle,
                "event" to if (result.blocked) "deliberation_blocked" else "deliberation",
                "rounds" to result.roundsUsed,
                "budget" to result.budget.maxRounds,
                "passed_eval" to result.passedEval,
                "notes" to result.evalNotes,
                "canon_mode" to canonMode,
                "directives" to dirsList
            )
        )

        if (result.blocked) {
            val rejected = CognitiveAtom(
                charge = -0.5,
                mass = 8.0,
                velocity = DoubleArray(semantic.dim),
                position = semantic.embed(result.text),
                tags = semantic.tagsFor(result.text),
                kind = "rejected",
                content = result.text,
                source = "generated",
                generator = "gemini",
                approved = false,
                directivesAtBirth = dirsList
            )
            field.inject(rejected)
            return result.text
        }

        // 7. Evaluation-gated quarantine write-back
        val eval = evaluator.evaluate(
            output = result.text,
            lockedIdentity = field.memory.lockedIdentity(),
            themes = field.memory.themes.values.toList(),
            directives = dirsList,
            preference = 0.5,
            recentGenerated = field.memory.quarantine.takeLast(8).map { it.position }
        )

        if (eval.passed || result.passedEval) {
            val massScale = 5.0 * (0.5 + eval.overall)
            val outAtom = CognitiveAtom(
                charge = 0.1,
                mass = massScale,
                velocity = DoubleArray(semantic.dim),
                position = semantic.embed(result.text),
                tags = semantic.tagsFor(result.text),
                kind = "quarantine",
                content = result.text,
                source = "generated",
                generator = "gemini",
                approved = false,
                directivesAtBirth = dirsList,
                evalScores = mapOf(
                    "identity" to eval.identityScore,
                    "theme" to eval.themeScore,
                    "constraint" to eval.constraintScore,
                    "novelty" to eval.noveltyScore,
                    "overall" to eval.overall
                )
            )
            field.inject(outAtom)
            log.add(
                mapOf(
                    "cycle" to cycle,
                    "event" to "quarantine_writeback",
                    "id" to outAtom.id,
                    "overall" to eval.overall
                )
            )
        } else {
            log.add(
                mapOf(
                    "cycle" to cycle,
                    "event" to "eval_reject_no_writeback",
                    "overall" to eval.overall,
                    "notes" to eval.notes
                )
            )
        }

        return result.text
    }
}
