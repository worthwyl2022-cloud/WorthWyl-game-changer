package com.example.core.substrate

/**
 * Dual-lane contradiction engine.
 *
 * Lane A — Affective: field conflict / identity_pressure (dynamical).
 * Lane B — Logical (NLI-proxy): lexical opposition + embedding anti-alignment
 * against locked identity. True CrossEncoder NLI is the upgrade path; this
 * Android build ships a deterministic proxy so PROTECT has teeth offline.
 */
data class ContradictionVerdict(
    val violated: Boolean,
    val principles: List<String>,
    val affectivePressure: Double,
    val logicalHits: List<String>,
    val lane: String // "affective" | "logical" | "both" | "none"
)

class ContradictionEngine(private val semantic: SemanticEngine) {

    private val oppositionPairs = listOf(
        "not optional" to "optional",
        "insufficient" to "sufficient",
        "necessary" to "unnecessary",
        "must remain" to "can discard",
        "protect" to "discard",
        "meaning" to "meaningless",
        "coherence" to "incoherence",
        "unity" to "segregation",
        "peace" to "domination",
        "forbidden" to "allowed"
    )

    /**
     * Logical lane: does [output] contradict locked identity atoms?
     */
    fun logicalViolation(
        output: String,
        locked: List<CognitiveAtom>
    ): Pair<Boolean, List<String>> {
        if (locked.isEmpty() || output.isBlank()) return false to emptyList()
        val outLower = output.lowercase()
        val outVec = semantic.embed(output)
        val violated = mutableListOf<String>()

        for (atom in locked) {
            val principle = atom.content.lowercase()
            val sim = cosine(outVec, atom.position)

            if (sim < -0.08 && atom.mass > 5.0) {
                violated += atom.content.take(80)
                continue
            }
            for ((pos, neg) in oppositionPairs) {
                if (pos in principle && neg in outLower && pos !in outLower) {
                    violated += atom.content.take(80)
                    break
                }
                if (neg in principle && pos in outLower && neg !in outLower) {
                    violated += atom.content.take(80)
                    break
                }
            }
        }
        return (violated.isNotEmpty()) to violated.distinct()
    }

    /**
     * Combined dual-lane verdict using live field metrics + logical check.
     */
    fun evaluate(
        output: String,
        locked: List<CognitiveAtom>,
        metrics: Map<String, Double>
    ): ContradictionVerdict {
        val (logicalHit, principles) = logicalViolation(output, locked)
        val pressure = metrics["identity_pressure"] ?: 0.0
        val conflict = metrics["conflict"] ?: 0.0
        val affectiveHot = pressure > 0.45 || conflict > 0.55

        val lane = when {
            logicalHit && affectiveHot -> "both"
            logicalHit -> "logical"
            affectiveHot -> "affective"
            else -> "none"
        }
        // PROTECT hard reject only on logical hits; affective drives directives upstream
        return ContradictionVerdict(
            violated = logicalHit,
            principles = principles,
            affectivePressure = maxOf(pressure, conflict),
            logicalHits = principles,
            lane = lane
        )
    }
}
